"use client";

import {
  type CSSProperties,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import styles from "./VehiclePropulsionGallery.module.css";

type DemonstrationState = "failed" | "testing" | "passed" | "prospective";

type DemonstrationCard = {
  id: string;
  title: string;
  architecture: string;
  state: DemonstrationState;
  stateLabel: string;
  rationale: string;
  evidence: string;
  takeaway: string;
};

const CLICK_COOLDOWN_MS = 400;
const HOVER_START_MS = 300;
const HOVER_REPEAT_MS = 650;
const SCROLL_END_MS = 150;
const EDGE_SELECTION_DELAY_MS = 450;
const PROGRAMMATIC_SCROLL_GUARD_MS = 700;
const SCRAMBLE_CHARACTERS = "!<>-_\\/[]{}—=+*^?#________";

const demonstrationCards: DemonstrationCard[] = [
  {
    id: "demo-a",
    title: "Architecture A",
    architecture: "Coaxial Rotor Configuration",
    state: "failed",
    stateLabel: "Failed",
    rationale: "Demonstrates how an architecture could remain visible after a declared constraint rules it out.",
    evidence: "No Ascerex evaluation is represented. A real entry would name its gate, model version, inputs, and evidence.",
    takeaway: "Literal exposed-rotor implementations conflict with the current Mk1 containment requirement.",
  },
  {
    id: "demo-e",
    title: "Architecture E",
    architecture: "Ducted Fan Assembly",
    state: "failed",
    stateLabel: "Failed",
    rationale: "Demonstrates how an architecture can remain visible while required source inputs are incomplete.",
    evidence: "No thrust, mass, energy, thermal, or installation values are asserted by this example.",
    takeaway: "A real candidate cannot enter screening until its evidence defines the applicable model boundary.",
  },
  {
    id: "demo-b",
    title: "Architecture B",
    architecture: "Distributed Electric Propulsion",
    state: "testing",
    stateLabel: "In Testing",
    rationale: "Demonstrates the presentation state for work that has started without producing an engineering outcome.",
    evidence: "This example does not imply that a distributed system is compatible, enclosed, feasible, or selected.",
    takeaway: "Real screening must preserve placement, containment, vectoring, and flight-role differences.",
  },
  {
    id: "demo-f",
    title: "Architecture F",
    architecture: "Quad Tilt-Wing",
    state: "testing",
    stateLabel: "In Testing",
    rationale: "Demonstrates how a concept can be retained without claiming that it is active or suitable for Mk1.",
    evidence: "No transition, structure, control, or packaging analysis is represented by this card.",
    takeaway: "Deferred concepts remain hypotheses until requirements and applicable models justify renewed work.",
  },
  {
    id: "demo-c",
    title: "Architecture C",
    architecture: "Tilt-Rotor Hybrid",
    state: "passed",
    stateLabel: "Passed Screening",
    rationale: "Demonstrates where scoped evidence would appear after a candidate meets explicitly defined criteria.",
    evidence: "No candidate has advanced through a gate here; this card demonstrates wording and layout only.",
    takeaway: "One screening gate would not establish aircraft feasibility, safety, certification, or selection.",
  },
  {
    id: "demo-d",
    title: "Architecture D",
    architecture: "Vectored Thrust Array",
    state: "prospective",
    stateLabel: "Prospective",
    rationale: "Demonstrates the earliest public state for an attributable architecture not yet screened.",
    evidence: "This example is not tied to a source vehicle or an Ascerex calculation.",
    takeaway: "Identification is an evidence-routing step, not a feasibility result or propulsion selection.",
  },
];

function ScrambleText({
  text,
  trigger,
  speed,
  delay = 0,
}: {
  text: string;
  trigger: number;
  speed: number;
  delay?: number;
}) {
  const [displayedText, setDisplayedText] = useState(text);

  useEffect(() => {
    if (trigger === 0) return;

    let intervalId: number | null = null;
    let cancelled = false;

    const delayId = window.setTimeout(() => {
      let iteration = 0;
      const maxIterations = Math.ceil(text.length * 1.5);

      const tick = () => {
        if (cancelled) return;

        const nextText = text
          .split("")
          .map((character, index) => {
            if (index < iteration / 1.5) return text[index];
            if (character === " ") return " ";
            return SCRAMBLE_CHARACTERS[
              Math.floor(Math.random() * SCRAMBLE_CHARACTERS.length)
            ];
          })
          .join("");

        setDisplayedText(nextText);
        iteration += 1;

        if (iteration >= maxIterations) {
          if (intervalId !== null) {
            window.clearInterval(intervalId);
            intervalId = null;
          }
          setDisplayedText(text);
        }
      };

      // Start immediately when the legacy delay expires instead of waiting
      // one extra interval before the first scrambled frame.
      tick();

      if (!cancelled && maxIterations > 1) {
        intervalId = window.setInterval(tick, speed);
      }
    }, delay);

    return () => {
      cancelled = true;
      window.clearTimeout(delayId);
      if (intervalId !== null) window.clearInterval(intervalId);
    };
  }, [delay, speed, text, trigger]);

  return (
    <span className={styles.scrambleText} aria-label={text}>
      <span aria-hidden="true">{displayedText}</span>
    </span>
  );
}

export function VehiclePropulsionGallery() {
  const trackRef = useRef<HTMLDivElement>(null);
  const expandedRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<Array<HTMLButtonElement | null>>([]);

  const currentIndexRef = useRef(0);
  const activeIdRef = useRef<string | null>(null);

  const clickCooldownRef = useRef(false);
  const autoScrollCooldownRef = useRef(false);
  const hoverDirectionRef = useRef<-1 | 0 | 1>(0);

  // A programmatic scroll must not be "corrected" by the manual-scroll snap
  // while its smooth animation is still running.
  const programmaticTargetRef = useRef<number | null>(null);

  const hoverTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scrollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cooldownTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autoCooldownTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const edgeSelectionTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const detailSwitchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const programmaticGuardTimerRef =
    useRef<ReturnType<typeof setTimeout> | null>(null);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [linePosition, setLinePosition] = useState(50);
  const [detailsSwitching, setDetailsSwitching] = useState(false);
  const [scrambleTriggers, setScrambleTriggers] =
    useState<Record<string, number>>({});

  const activeCard =
    demonstrationCards.find((card) => card.id === activeId) ?? null;

  const setCurrentCardIndex = useCallback((index: number) => {
    const nextIndex = Math.max(
      0,
      Math.min(demonstrationCards.length - 1, index),
    );
    currentIndexRef.current = nextIndex;
    setCurrentIndex(nextIndex);
    return nextIndex;
  }, []);

  /**
   * Center from the card's actual rendered geometry.
   *
   * This intentionally replaces the old "card width + fixed gap + inferred
   * spacer width" arithmetic. CSS pseudo-spacers, responsive percentages and
   * flex gaps are already represented by offsetLeft/offsetWidth, so using the
   * DOM geometry prevents the carousel from oscillating between two targets.
   */
  const getCardScrollTarget = useCallback((index: number) => {
    const track = trackRef.current;
    const card = cardRefs.current[index];
    if (!track || !card) return 0;

    const maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
    const centered =
      card.offsetLeft - (track.clientWidth - card.offsetWidth) / 2;

    return Math.max(0, Math.min(maxScroll, centered));
  }, []);

  const getNearestIndex = useCallback(() => {
    const track = trackRef.current;
    if (!track) return currentIndexRef.current;

    let nearestIndex = currentIndexRef.current;
    let nearestDistance = Number.POSITIVE_INFINITY;

    cardRefs.current.forEach((card, index) => {
      if (!card) return;
      const distance = Math.abs(
        track.scrollLeft - getCardScrollTarget(index),
      );

      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestIndex = index;
      }
    });

    return nearestIndex;
  }, [getCardScrollTarget]);

  const releaseProgrammaticScroll = useCallback((target?: number) => {
    if (
      target !== undefined &&
      programmaticTargetRef.current !== target
    ) {
      return;
    }

    programmaticTargetRef.current = null;

    if (programmaticGuardTimerRef.current) {
      clearTimeout(programmaticGuardTimerRef.current);
      programmaticGuardTimerRef.current = null;
    }
  }, []);

  const scrollToCard = useCallback(
    (index: number, behavior: ScrollBehavior = "smooth") => {
      const track = trackRef.current;
      if (!track) return;

      const nextIndex = setCurrentCardIndex(index);
      const target = getCardScrollTarget(nextIndex);

      if (behavior === "smooth") {
        programmaticTargetRef.current = nextIndex;

        if (programmaticGuardTimerRef.current) {
          clearTimeout(programmaticGuardTimerRef.current);
        }

        // Fallback release for browsers that do not give us a final scroll
        // event exactly at the target.
        programmaticGuardTimerRef.current = setTimeout(() => {
          releaseProgrammaticScroll(nextIndex);
        }, PROGRAMMATIC_SCROLL_GUARD_MS);
      } else {
        releaseProgrammaticScroll();
      }

      track.scrollTo({ left: target, behavior });
    },
    [
      getCardScrollTarget,
      releaseProgrammaticScroll,
      setCurrentCardIndex,
    ],
  );

  const moveOneCard = useCallback(
    (direction: -1 | 1) => {
      const nearestIndex = Math.max(
        0,
        Math.min(demonstrationCards.length - 1, getNearestIndex()),
      );
      const nextIndex = Math.max(
        0,
        Math.min(
          demonstrationCards.length - 1,
          nearestIndex + direction,
        ),
      );

      if (nextIndex === nearestIndex) return false;

      scrollToCard(nextIndex);
      return true;
    },
    [getNearestIndex, scrollToCard],
  );

  const updateLinePosition = useCallback((cardId: string) => {
    const expanded = expandedRef.current;
    const cardIndex = demonstrationCards.findIndex(
      (card) => card.id === cardId,
    );
    const card = cardRefs.current[cardIndex];

    if (!expanded || !card) return;

    const cardRect = card.getBoundingClientRect();
    const expandedRect = expanded.getBoundingClientRect();
    if (expandedRect.width === 0) return;

    const cardCenter =
      cardRect.left + cardRect.width / 2 - expandedRect.left;

    setLinePosition(
      Math.max(
        5,
        Math.min(95, (cardCenter / expandedRect.width) * 100),
      ),
    );
  }, []);

  const cancelEdgeSelection = useCallback(() => {
    if (edgeSelectionTimerRef.current) {
      clearTimeout(edgeSelectionTimerRef.current);
      edgeSelectionTimerRef.current = null;
    }
  }, []);

  const closeExpanded = useCallback(() => {
    if (detailSwitchTimerRef.current) {
      clearTimeout(detailSwitchTimerRef.current);
      detailSwitchTimerRef.current = null;
    }

    setDetailsSwitching(false);
    activeIdRef.current = null;
    setActiveId(null);
  }, []);

  const showExpanded = useCallback(
    (cardId: string) => {
      const switchingCards = Boolean(
        activeIdRef.current && activeIdRef.current !== cardId,
      );

      if (detailSwitchTimerRef.current) {
        clearTimeout(detailSwitchTimerRef.current);
      }

      if (switchingCards) setDetailsSwitching(true);

      activeIdRef.current = cardId;
      setActiveId(cardId);

      // Wait for React to commit data-active/content before measuring the
      // connector. Two animation frames keeps the line tied to the final card
      // position without visually delaying the details.
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => updateLinePosition(cardId));
      });

      if (switchingCards) {
        detailSwitchTimerRef.current = setTimeout(() => {
          setDetailsSwitching(false);
          detailSwitchTimerRef.current = null;
        }, 50);
      }
    },
    [updateLinePosition],
  );

  const cardIsVisible = useCallback(
    (index: number, fully: boolean) => {
      const track = trackRef.current;
      const card = cardRefs.current[index];

      if (!track || !card) return false;

      const trackRect = track.getBoundingClientRect();
      const cardRect = card.getBoundingClientRect();

      if (fully) {
        const tolerance = 10;
        return (
          cardRect.left >= trackRect.left - tolerance &&
          cardRect.right <= trackRect.right + tolerance
        );
      }

      const center = cardRect.left + cardRect.width / 2;
      const buffer = 50;
      return (
        center > trackRect.left - buffer &&
        center < trackRect.right + buffer
      );
    },
    [],
  );

  function beginHoverAdvance(direction: -1 | 1) {
    if (clickCooldownRef.current) return;

    if (
      (direction === -1 && currentIndexRef.current === 0) ||
      (direction === 1 &&
        currentIndexRef.current === demonstrationCards.length - 1)
    ) {
      return;
    }

    if (hoverTimerRef.current) clearTimeout(hoverTimerRef.current);

    hoverTimerRef.current = setTimeout(() => {
      if (
        clickCooldownRef.current ||
        hoverDirectionRef.current !== direction
      ) {
        return;
      }

      moveOneCard(direction);
      autoScrollCooldownRef.current = true;

      if (autoCooldownTimerRef.current) {
        clearTimeout(autoCooldownTimerRef.current);
      }

      autoCooldownTimerRef.current = setTimeout(() => {
        autoScrollCooldownRef.current = false;
      }, CLICK_COOLDOWN_MS);

      hoverTimerRef.current = setTimeout(() => {
        const canContinue =
          (direction === 1 &&
            hoverDirectionRef.current === 1 &&
            currentIndexRef.current <
              demonstrationCards.length - 1) ||
          (direction === -1 &&
            hoverDirectionRef.current === -1 &&
            currentIndexRef.current > 0);

        if (!clickCooldownRef.current && canContinue) {
          beginHoverAdvance(direction);
        }
      }, HOVER_REPEAT_MS);
    }, HOVER_START_MS);
  }

  const handleNavClick = (direction: -1 | 1) => {
    cancelEdgeSelection();

    if (hoverTimerRef.current) clearTimeout(hoverTimerRef.current);

    if (autoScrollCooldownRef.current) {
      autoScrollCooldownRef.current = false;
      hoverDirectionRef.current = 0;
      clickCooldownRef.current = true;

      if (cooldownTimerRef.current) {
        clearTimeout(cooldownTimerRef.current);
      }

      cooldownTimerRef.current = setTimeout(() => {
        clickCooldownRef.current = false;
      }, 100);

      return;
    }

    moveOneCard(direction);
    clickCooldownRef.current = true;

    if (cooldownTimerRef.current) {
      clearTimeout(cooldownTimerRef.current);
    }

    cooldownTimerRef.current = setTimeout(() => {
      clickCooldownRef.current = false;
    }, CLICK_COOLDOWN_MS);
  };

  const handleNavEnter = (direction: -1 | 1) => {
    const isTouchDevice =
      "ontouchstart" in window || navigator.maxTouchPoints > 0;

    if (isTouchDevice) return;

    hoverDirectionRef.current = direction;
    beginHoverAdvance(direction);
  };

  const handleNavLeave = () => {
    hoverDirectionRef.current = 0;

    if (hoverTimerRef.current) {
      clearTimeout(hoverTimerRef.current);
    }
  };

  const handleCardClick = (card: DemonstrationCard, index: number) => {
    cancelEdgeSelection();

    if (activeIdRef.current === card.id) {
      closeExpanded();
      return;
    }

    if (!cardIsVisible(index, true)) {
      // We know exactly which edge card was clicked. Center that card
      // directly rather than deriving "next/previous" from a scroll position
      // that is itself currently moving.
      scrollToCard(index);

      edgeSelectionTimerRef.current = setTimeout(() => {
        edgeSelectionTimerRef.current = null;
        showExpanded(card.id);
      }, EDGE_SELECTION_DELAY_MS);

      return;
    }

    showExpanded(card.id);
  };

  const handleCardHover = (cardId: string) => {
    setScrambleTriggers((current) => ({
      ...current,
      [cardId]: (current[cardId] ?? 0) + 1,
    }));
  };

  const handleTrackScroll = () => {
    if (scrollTimerRef.current) {
      clearTimeout(scrollTimerRef.current);
    }

    const selectedId = activeIdRef.current;

    if (selectedId) {
      const selectedIndex = demonstrationCards.findIndex(
        (card) => card.id === selectedId,
      );

      if (cardIsVisible(selectedIndex, false)) {
        updateLinePosition(selectedId);
      } else {
        closeExpanded();
      }
    }

    scrollTimerRef.current = setTimeout(() => {
      const nearestIndex = Math.max(
        0,
        Math.min(demonstrationCards.length - 1, getNearestIndex()),
      );

      const programmaticTarget = programmaticTargetRef.current;

      // Critical race fix:
      // a smooth scroll initiated by nav/edge selection is already headed
      // toward a known card. Do not launch another smooth scroll at 150 ms.
      if (programmaticTarget !== null) {
        if (nearestIndex === programmaticTarget) {
          setCurrentCardIndex(programmaticTarget);
          releaseProgrammaticScroll(programmaticTarget);
        }
        return;
      }

      if (hoverDirectionRef.current !== 0) return;

      // Manual wheel/trackpad/touch scrolling keeps the legacy 150 ms snap.
      scrollToCard(nearestIndex);
    }, SCROLL_END_MS);
  };

  useEffect(() => {
    const initializeId = window.setTimeout(
      () => scrollToCard(0, "auto"),
      100,
    );

    const handleResize = () => {
      scrollToCard(currentIndexRef.current, "auto");

      if (activeIdRef.current) {
        window.requestAnimationFrame(() => {
          if (activeIdRef.current) {
            updateLinePosition(activeIdRef.current);
          }
        });
      }
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.clearTimeout(initializeId);
      window.removeEventListener("resize", handleResize);

      [
        hoverTimerRef,
        scrollTimerRef,
        cooldownTimerRef,
        autoCooldownTimerRef,
        edgeSelectionTimerRef,
        detailSwitchTimerRef,
        programmaticGuardTimerRef,
      ].forEach((timerRef) => {
        if (timerRef.current) clearTimeout(timerRef.current);
      });
    };
  }, [scrollToCard, updateLinePosition]);

  const lineStyle = {
    "--line-position": `${linePosition}%`,
  } as CSSProperties;

  return (
    <div className={styles.gallery}>
      <aside
        className={styles.notice}
        aria-label="Propulsion gallery status"
      >
        <span>Demonstrative interface</span>
        <p>
          These cards demonstrate future screening states and interactions.
          They are not candidate records, test results, engineering findings,
          or propulsion selections.
        </p>
      </aside>

      <div className={styles.carousel}>
        <button
          type="button"
          className={`${styles.navField} ${styles.navLeft}`}
          aria-label="Previous propulsion demonstration"
          aria-disabled={currentIndex === 0}
          onClick={() => handleNavClick(-1)}
          onMouseEnter={() => handleNavEnter(-1)}
          onMouseLeave={handleNavLeave}
        >
          <svg
            className={styles.navArrow}
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <polyline points="15,18 9,12 15,6" />
          </svg>
        </button>

        <button
          type="button"
          className={`${styles.navField} ${styles.navRight}`}
          aria-label="Next propulsion demonstration"
          aria-disabled={
            currentIndex === demonstrationCards.length - 1
          }
          onClick={() => handleNavClick(1)}
          onMouseEnter={() => handleNavEnter(1)}
          onMouseLeave={handleNavLeave}
        >
          <svg
            className={styles.navArrow}
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <polyline points="9,18 15,12 9,6" />
          </svg>
        </button>

        <div className={styles.trackFrame}>
          <div
            ref={trackRef}
            className={styles.track}
            aria-label="Demonstrative propulsion screening cards"
            onScroll={handleTrackScroll}
          >
            {demonstrationCards.map((card, index) => {
              const selected = card.id === activeId;
              const trigger = scrambleTriggers[card.id] ?? 0;

              return (
                <button
                  key={card.id}
                  ref={(element) => {
                    cardRefs.current[index] = element;
                  }}
                  type="button"
                  className={styles.card}
                  data-status={card.state}
                  data-active={selected || undefined}
                  aria-expanded={selected}
                  aria-controls="propulsion-demonstration-details"
                  onClick={() => handleCardClick(card, index)}
                  onMouseEnter={() => handleCardHover(card.id)}
                  onFocus={() => handleCardHover(card.id)}
                >
                  <span
                    className={styles.cardCorners}
                    aria-hidden="true"
                  />
                  <span className={styles.cardInner}>
                    <span className={styles.cardTitle}>
                      {card.title}
                    </span>
                  </span>
                  <span className={styles.cardReveal}>
                    <span className={styles.cardType}>
                      <ScrambleText
                        text={card.architecture}
                        trigger={trigger}
                        speed={15}
                      />
                    </span>
                    <span className={styles.cardStatus}>
                      <ScrambleText
                        text={card.stateLabel}
                        trigger={trigger}
                        speed={20}
                        delay={100}
                      />
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div
        ref={expandedRef}
        id="propulsion-demonstration-details"
        className={styles.expandedWrapper}
        data-open={Boolean(activeCard) || undefined}
        data-status={activeCard?.state}
        data-switching={detailsSwitching || undefined}
        aria-hidden={!activeCard}
        style={lineStyle}
      >
        <div className={styles.expandedContent}>
          <span className={styles.expandedLine} aria-hidden="true" />

          {activeCard ? (
            <section
              key={activeCard.id}
              className={styles.expandedBody}
              aria-live="polite"
            >
              <header className={styles.expandedHeader}>
                <h3>{activeCard.title}</h3>
                <div className={styles.expandedMeta}>
                  <span>{activeCard.architecture}</span>
                  <strong>{activeCard.stateLabel}</strong>
                </div>
              </header>

              <dl className={styles.expandedDetails}>
                <div>
                  <dt>Example evaluation rationale</dt>
                  <dd>{activeCard.rationale}</dd>
                </div>
                <div>
                  <dt>Evidence represented</dt>
                  <dd>{activeCard.evidence}</dd>
                </div>
                <div>
                  <dt>Example takeaway</dt>
                  <dd>{activeCard.takeaway}</dd>
                </div>
              </dl>
            </section>
          ) : null}
        </div>
      </div>
    </div>
  );
}
